using UnityEngine;

/// <summary> This is just used as a target to send the camera to. </summary>
public class CameraTarget : MonoBehaviour
{
    // This is only really used as a tag so no code really needed.
}
